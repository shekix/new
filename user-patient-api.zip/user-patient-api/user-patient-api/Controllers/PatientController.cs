﻿using Domain.Patient;
using infrastructure;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace user_patient_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientController : ControllerBase
    {
        private readonly AppDbContext _context;

        public PatientController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost("AddPatient")]
        public IActionResult AddPateint(Patientdto dto,string id)
        {
            if(_context.Patients.Where(p=>p.Email == dto.Email).FirstOrDefault() != null)
            {
                return Ok("AlreadyExists");
            }

            var lastPatient = _context.Patients.OrderByDescending(p => p.Id).FirstOrDefault();
            string newPatientId;
            if (lastPatient == null)
            {
                // Initialize if the table is empty
                newPatientId = (id+"0001").ToString();
               
            }
            else
            {
                int lastPatientNumber = Convert.ToInt32(lastPatient.Id.Substring(7));
                int newPatientNumber = lastPatientNumber + 1;
                newPatientId = id+newPatientNumber.ToString("D4");
            }

            var patient = new Patient
            {
                Id = newPatientId,
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                Gender = dto.Gender,
                Dob = dto.Dob,
                MaritalStatus = dto.MaritalStatus,
                BloodGroup = dto.BloodGroup,
                PhoneNumber = dto.PhoneNumber,
                Email = dto.Email,
                AddressLine1 = dto.AddressLine1,
                AddressLine2 = dto.AddressLine2,
                Country = dto.Country,
                State = dto.State,
                City = dto.City,
                PastMedicalHistory = dto.PastMedicalHistory,
                CurrentIllness = dto.CurrentIllness,
                TreatedBy = dto.TreatedBy,
                TreatmentStatus = dto.TreatmentStatus,
                InsuranceId = dto.InsuranceId,
                InsuranceName = dto.InsuranceName,
                Coverage = dto.Coverage,
                EmergencyContactName = dto.EmergencyContactName,
                EmergencyContactNumber = dto.EmergencyContactNumber,
                CreatedOn = DateTime.Now,
                LastUpdatedOn = DateTime.Now,
                IsActive = true,
            };

            _context.Patients.Add(patient);
            _context.SaveChanges();

            return Ok("PateintAdded");
        }

        [HttpGet]
        public IActionResult getPateints()
        {
            var patients = _context.Patients.ToList();
            return Ok(patients);
        }

        [HttpPut]
        public IActionResult updatePateint(Patientdto dto,string id)
        {
            var patient = _context.Patients.Find(id);
            if (patient == null)
            {
                return Ok("Patient not found");
            }
            patient.FirstName = dto.FirstName;
            patient.LastName = dto.LastName;
            patient.Email = dto.Email;
            patient.Gender = dto.Gender;
            patient.Dob = dto.Dob;
            patient.PhoneNumber = dto.PhoneNumber;
            patient.Email = dto.Email;
            patient.AddressLine1 = dto.AddressLine1;
            patient.AddressLine2 = dto.AddressLine2;
            patient.Country = dto.Country;
            patient.City = dto.City;
            patient.State = dto.State;
            patient.MaritalStatus = dto.MaritalStatus;
            patient.PastMedicalHistory = dto.PastMedicalHistory;
            patient.CurrentIllness = dto.CurrentIllness;
            patient.TreatedBy = dto.TreatedBy;
            patient.TreatmentStatus = dto.TreatmentStatus;
            patient.InsuranceName = dto.InsuranceName;
            patient.InsuranceId = dto.InsuranceId;
            patient.EmergencyContactName = dto.EmergencyContactName;
            patient.EmergencyContactNumber = dto.EmergencyContactNumber;
            patient.LastUpdatedOn = DateTime.Now;
            patient.IsActive = true;

             _context.SaveChanges();
            return Ok("Patient Updated");
        }
    }
}
